App({
  onLaunch: function () {
      wx.cloud.init({
        env: 'assistant-7gbpbxo648076a5c', 
        traceUser: true,
      })
  }
});
