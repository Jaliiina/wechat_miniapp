const db = wx.cloud.database(); 
const itemsCollection = db.collection("items"); 

Page({
  data: {
    imagePath: "", 
    formData: {
      name: "",
      category: "",
      location: "",
      quantity: "",
    },
    categories: ["电子产品", "厨房用品", "书籍", "衣物", "其他"],
    categoryIndex: null, 
  },

  // 选择图片
  chooseImage() {
    wx.chooseImage({
      count: 1,
      success: (res) => {
        this.setData({
          imagePath: res.tempFilePaths[0], 
        });
      },
    });
  },

  onCategoryChange(e) {
    const index = e.detail.value;
    this.setData({
      categoryIndex: index,
      "formData.category": this.data.categories[index], 
    });
  },

  onSubmit(e) {
    const { imagePath, formData } = this.data; 
    const { name, location, quantity } = e.detail.value;

    if (!imagePath || !name || !formData.category || !location || !quantity) {
      wx.showToast({
        title: "请完整填写信息",
        icon: "error",
      });
      return;
    }

    wx.cloud.uploadFile({
      cloudPath: `items/${Date.now()}-${Math.random() * 1000000}.png`,
      filePath: imagePath,
      success: (uploadRes) => {
        itemsCollection.add({
          data: {
            name: name,
            category: formData.category,
            location: location,
            quantity: parseInt(quantity),
            image: uploadRes.fileID,
            createdAt: new Date(),
          },
          success: (res) => {
            wx.showToast({ title: "上传成功", icon: "success" });

            this.setData({
              imagePath: "",
              formData: {
                name: "",
                category: "",
                location: "",
                quantity: "",
              },
              categoryIndex: null,
            });
          },
        });
      },
    });
  },
});
