const db = wx.cloud.database();
const itemsCollection = db.collection("items");

Page({
  data: {
    categories: ["全部", "电子产品", "厨房用品", "书籍",  "衣物","其他"],
    categoryIndex: 0,
    items: [], 
  },

  onLoad() {
    this.fetchItems();
  },

  
  fetchItems() {
    const category = this.data.categories[this.data.categoryIndex];
    let query = itemsCollection;

    if (category !== "全部") {
      query = query.where({ category });
    }

    query.get().then((res) => {
      this.setData({ items: res.data });
    });
  },

  onCategoryChange(e) {
    const index = e.detail.value;
    this.setData({ categoryIndex: index }, this.fetchItems);
  },

  onDelete(e) {
    const itemId = e.currentTarget.dataset.id;

    wx.showModal({
      title: "确认删除",
      content: "确定要删除此物品吗？",
      success: (res) => {
        if (res.confirm) {
          // 调用数据库删除
          itemsCollection
            .doc(itemId)
            .remove()
            .then(() => {
              wx.showToast({ title: "删除成功", icon: "success" });
              this.fetchItems(); // 刷新列表
            })
            .catch((err) => {
              console.error("删除失败：", err);
              wx.showToast({ title: "删除失败", icon: "error" });
            });
        }
      },
    });
  },
});
