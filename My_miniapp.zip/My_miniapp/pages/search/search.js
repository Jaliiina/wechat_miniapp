const db = wx.cloud.database();
const itemsCollection = db.collection("items");

Page({
  data: {
    query: "", 
    results: [],
  },

  onInput(e) {
    this.setData({ query: e.detail.value });
  },

  // 搜索
  async onSearch() {
    const query = this.data.query.trim();

    if (!query) {
      wx.showToast({ title: "请输入搜索关键字", icon: "none" });
      return;
    }

    try {
      const res = await itemsCollection
        .where(
          db.command.or([
            {
              name: db.RegExp({
                regexp: query,
                options: "i", 
              }),
            },
            {
              category: db.RegExp({
                regexp: query,
                options: "i",
              }),
            },
          ])
        )
        .get();

      // 设置结果到页面
      this.setData({ results: res.data });
    } catch (error) {
      console.error("搜索失败：", error);
      wx.showToast({ title: "搜索失败，请稍后重试", icon: "error" });
    } finally {
      wx.hideLoading(); 
    }
  },
});
