Page({

  data: {
    source:[
      "https://tse4-mm.cn.bing.net/th/id/OIP-C.Jl-LlnVXdAVyqB3L6vnMJgHaG4?w=219&h=204&c=7&r=0&o=5&dpr=2&pid=1.7",
      "https://tse1-mm.cn.bing.net/th/id/OIP-C.3DCzwpEBQdr9BD-9nzD4YAHaHa?w=205&h=204&c=7&r=0&o=5&dpr=2&pid=1.7",
      "https://tse4-mm.cn.bing.net/th/id/OIP-C.f_ovbauQY1IC8kN2_yg74AHaJ3?w=156&h=180&c=7&r=0&o=5&dpr=2&pid=1.7"]
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})